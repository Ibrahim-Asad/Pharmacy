/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pharmacy_project;

/**
 *
 * @author ibrah
 */
public class Pharmacy_Project {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        spalashStreem s1=new spalashStreem();
        s1.setVisible(true);
    }
}
