/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pharmacy_project;

/**
 *
 * @author ibrah
 */
public class Constants {
    
    public static String URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static String USER = "c##project";
    public static String PASSWORD = "3";
    
}
